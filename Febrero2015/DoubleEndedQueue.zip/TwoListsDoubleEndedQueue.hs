-------------------------------------------------------------------------------
-- Estructuras de Datos. Grado en Informática, IS e IC. UMA.
-- Examen de Febrero 2015.
--
-- Implementación del TAD Deque
--
-- Apellidos:
-- Nombre:
-- Grado en Ingeniería ...
-- Grupo:
-- Número de PC:
-------------------------------------------------------------------------------

module TwoListsDoubleEndedQueue
   ( DEQue
   , empty
   , isEmpty
   , first
   , last
   , addFirst
   , addLast
   , deleteFirst
   , deleteLast
   ) where

import Prelude hiding (last)
import Data.List(intercalate)
import Test.QuickCheck

data DEQue a = DEQ [a] [a]

-- Complexity:
empty :: DEQue a
empty = DEQ [] []

-- Complexity:
isEmpty :: DEQue a -> Bool
isEmpty empty = True
isEmpty _     = False

-- Complexity:
addFirst :: a -> DEQue a -> DEQue a
addFirst x (DEQ [] last) = DEQ [x] (last)
addFirst x (DEQ first last) = DEQ (x:first) (last)


-- Complexity:
addLast :: a -> DEQue a -> DEQue a
addLast  x (DEQ (first) []) = DEQ (first) [x]
addLast x (DEQ first last) = DEQ (first) (x:last)

-- Complexity:
first :: DEQue a -> a
first (DEQ (x:xs) (y:ys)) = x
first (DEQ [] last) = head (reverse last)


-- Complexity:
last :: DEQue a -> a
last (DEQ [] []) = error "Lista Vacía"
last (DEQ (x:xs) (y:ys)) = y
last (DEQ first []) = head (reverse first)

-- Complexity:
deleteFirst :: DEQue a -> DEQue a
deleteFirst (DEQ [] []) = DEQ [] []
deleteFirst (DEQ (x:xs) last) = DEQ (xs) last
deleteFirst (DEQ [] last) = deleteFirst (balance last)


balance :: [a] -> DEQue a
balance last = DEQ lista1 lista2
   where
      lista1 = reverse (snd (splitAt ((length last)`div`2) last))
      lista2 =  fst (splitAt ((length last)`div`2) last)

-- Complexity:
deleteLast :: DEQue a -> DEQue a
deleteLast (DEQ [] []) = DEQ [] []
deleteLast (DEQ first (y:ys)) = DEQ first (ys)
deleteLast (DEQ first []) = deleteFirst (balance' first)

balance' :: [a] -> DEQue a
balance' first = DEQ lista1 lista2
   where
      lista1 =  fst (splitAt ((length first)`div`2) first)
      lista2 = reverse (snd (splitAt ((length first)`div`2) first))


instance (Show a) => Show (DEQue a) where
   show q = "TwoListsDoubleEndedQueue(" ++ intercalate "," [show x | x <- toList q] ++ ")"

toList :: DEQue a -> [a]
toList (DEQ xs ys) =  xs ++ reverse ys

instance (Eq a) => Eq (DEQue a) where
   q == q' =  toList q == toList q'

instance (Arbitrary a) => Arbitrary (DEQue a) where
   arbitrary =  do
      xs <- listOf arbitrary
      ops <- listOf (oneof [return addFirst, return addLast])
      return (foldr id empty (zipWith ($) ops xs))

q1 :: Num a => DEQue a
q1 = DEQ [2,3,4] [7,6,5]

q2 :: Num a => DEQue a
q2 = addFirst 1 q1
